var searchData=
[
  ['cargarbuffer',['CargarBuffer',['../_fun_servidor_8c.html#aa8be61c138c7a6599ec37e37cd84bd06',1,'CargarBuffer(FILE *fd_libro, char *bufferlibro):&#160;FunServidor.c'],['../_servidor_8h.html#aaa33dbae4d3d40d5e982180ca5a2ab1c',1,'CargarBuffer(FILE *, char *):&#160;FunServidor.c']]],
  ['cargardatoslista',['CargarDatosLista',['../_fun_servidor_8c.html#ab62e9cc48f5c76c249c5e53a4f77ff55',1,'CargarDatosLista(char *pathestructura):&#160;FunServidor.c'],['../_servidor_8h.html#ad84b0c36787ef484cf4f2e9f279a6e23',1,'CargarDatosLista(char *):&#160;FunServidor.c']]]
];
