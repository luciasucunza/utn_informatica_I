var searchData=
[
  ['guardarpath',['GuardarPath',['../_fun_servidor_8c.html#aeb1930b7037075ff04a2a4197ef4cd2c',1,'GuardarPath(char *titulo, char *pathlibro):&#160;FunServidor.c'],['../_servidor_8h.html#acc78a1d6c0587e6886bd4320bde292ed',1,'GuardarPath(char *, char *):&#160;FunServidor.c']]]
];
