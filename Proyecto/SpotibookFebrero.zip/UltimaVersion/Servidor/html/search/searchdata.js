var indexSectionsWithContent =
{
  0: "bcefgimnrsv",
  1: "bcn",
  2: "fs",
  3: "bcefgimrsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Estructuras de Datos",
  2: "Archivos",
  3: "Funciones"
};

