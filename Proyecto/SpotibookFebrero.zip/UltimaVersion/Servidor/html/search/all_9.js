var searchData=
[
  ['servidor_2ec',['Servidor.c',['../_servidor_8c.html',1,'']]],
  ['servidor_2eh',['Servidor.h',['../_servidor_8h.html',1,'']]],
  ['sigchld_5fhandler',['sigchld_handler',['../_fun_servidor_8c.html#a6c2d9589ac70568b8e3a6980bb3d45d6',1,'sigchld_handler(int s):&#160;FunServidor.c'],['../_servidor_8h.html#a97fb740114509c637bbe37c21d240e35',1,'sigchld_handler(int):&#160;FunServidor.c']]]
];
