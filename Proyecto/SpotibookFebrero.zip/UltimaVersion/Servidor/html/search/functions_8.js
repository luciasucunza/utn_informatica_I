var searchData=
[
  ['sigchld_5fhandler',['sigchld_handler',['../_fun_servidor_8c.html#a6c2d9589ac70568b8e3a6980bb3d45d6',1,'sigchld_handler(int s):&#160;FunServidor.c'],['../_servidor_8h.html#a97fb740114509c637bbe37c21d240e35',1,'sigchld_handler(int):&#160;FunServidor.c']]]
];
