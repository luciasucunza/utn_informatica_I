var searchData=
[
  ['inicializarservidor',['InicializarServidor',['../_fun_servidor_8c.html#a2273ed43ee83a86ddba9e192718d5291',1,'InicializarServidor(void):&#160;FunServidor.c'],['../_servidor_8h.html#a2273ed43ee83a86ddba9e192718d5291',1,'InicializarServidor(void):&#160;FunServidor.c']]]
];
