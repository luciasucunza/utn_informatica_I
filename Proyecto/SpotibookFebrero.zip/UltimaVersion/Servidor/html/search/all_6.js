var searchData=
[
  ['mystrcmp',['MyStrcmp',['../_fun_servidor_8c.html#a74944ef3d41df9668eaa1bda100fa2c3',1,'MyStrcmp(char *texto, char *palabra):&#160;FunServidor.c'],['../_servidor_8h.html#a369cf43fcbda77b7f45633389b9d49f5',1,'MyStrcmp(char *, char *):&#160;FunServidor.c']]]
];
