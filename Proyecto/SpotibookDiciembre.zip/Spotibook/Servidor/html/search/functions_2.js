var searchData=
[
  ['enviararchivo',['EnviarArchivo',['../_fun_servidor_8c.html#aea0897d99d1b351dd0a3cf5f4aaa9a3e',1,'EnviarArchivo(char *path, int sockfd):&#160;FunServidor.c'],['../_servidor_8h.html#aea9a7e75cadd612eaa92175a2e5bfa78',1,'EnviarArchivo(char *, int):&#160;FunServidor.c']]]
];
