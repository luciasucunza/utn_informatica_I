var searchData=
[
  ['recibirlista',['RecibirLista',['../_fun_servidor_8c.html#a061b683823937e09b42e0b80f60bcc6b',1,'RecibirLista(char *path, int sockfd):&#160;FunServidor.c'],['../_servidor_8h.html#a6fa670a7ee71b828a97ad03218d68f91',1,'RecibirLista(char *, int):&#160;FunServidor.c']]]
];
