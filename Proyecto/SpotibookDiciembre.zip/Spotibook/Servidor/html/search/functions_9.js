var searchData=
[
  ['verificaruser',['VerificarUser',['../_fun_servidor_8c.html#a75599f2f5f4566cbeaf86ceb8999b8bc',1,'VerificarUser(nodo *nodoprimero, char *user, char *pass):&#160;FunServidor.c'],['../_servidor_8h.html#a675d1cc3987880eb53bd6ee31c5c56e3',1,'VerificarUser(nodo *, char *, char *):&#160;FunServidor.c']]]
];
