var searchData=
[
  ['funcionadmin',['FuncionAdmin',['../_fun_servidor_8c.html#ac29da5ca4bc99e0b691db90983192c14',1,'FuncionAdmin(int sockfd, struct in_addr ip_cliente):&#160;FunServidor.c'],['../_servidor_8h.html#ab240238ca747000bc0a616b4a2eb521b',1,'FuncionAdmin(int, struct in_addr):&#160;FunServidor.c']]],
  ['funcionuser',['FuncionUser',['../_fun_servidor_8c.html#a110cdcf850f816f4729979a400939f8c',1,'FuncionUser(int sockfd, struct in_addr ip_cliente):&#160;FunServidor.c'],['../_servidor_8h.html#a1ab5ffca5d5f1436ee870962d0709a6c',1,'FuncionUser(int, struct in_addr):&#160;FunServidor.c']]]
];
