var searchData=
[
  ['nodo_5ft',['nodo_t',['../structnodo__t.html',1,'']]]
];
