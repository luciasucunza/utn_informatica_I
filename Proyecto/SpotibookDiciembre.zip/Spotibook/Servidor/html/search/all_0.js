var searchData=
[
  ['borrarlista',['BorrarLista',['../_fun_servidor_8c.html#aaa3c708a36a8c249caf677e3543d156c',1,'BorrarLista(nodo **nodoprimero):&#160;FunServidor.c'],['../_servidor_8h.html#a6f202357db6ac07b8e7d6182aad2497e',1,'BorrarLista(nodo **):&#160;FunServidor.c']]],
  ['busqueda_5ft',['busqueda_t',['../structbusqueda__t.html',1,'']]],
  ['busquedalibro',['BusquedaLibro',['../_fun_servidor_8c.html#ab2aadc510d235b10b97a2003be2b93c3',1,'BusquedaLibro(busqueda *criterio, nodo *nodooriginal):&#160;FunServidor.c'],['../_servidor_8h.html#a7972996e57a6e8534eec2849eeb915cc',1,'BusquedaLibro(busqueda *, nodo *):&#160;FunServidor.c']]]
];
