var searchData=
[
  ['buscarnodo',['BuscarNodo',['../_cliente_8h.html#a0c34d0f42687c0d20bcae8851cb49a9e',1,'BuscarNodo(nodo *, char *):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a313be91444ab593f9fea7dc223b02b45',1,'BuscarNodo(nodo *nodoprimero, char *cadena):&#160;FunCliente.c']]]
];
