var searchData=
[
  ['agregarnodo',['AgregarNodo',['../_cliente_8h.html#a0f6646b7dac3beb0deec9a873256f03c',1,'AgregarNodo(nodo **, int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a8b828f98b05022cae4db7851e6474685',1,'AgregarNodo(nodo **nodoprimero, int manejo):&#160;FunCliente.c']]]
];
