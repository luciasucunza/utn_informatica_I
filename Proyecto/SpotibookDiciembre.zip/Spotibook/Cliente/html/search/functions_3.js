var searchData=
[
  ['enviarlista',['EnviarLista',['../_cliente_8h.html#abd2cafee03231c012e0f9bee11a34553',1,'EnviarLista(nodo *, int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a051813defc0350242f40635d9e7338a8',1,'EnviarLista(nodo *nodoprimero, int sockfd):&#160;FunCliente.c']]]
];
