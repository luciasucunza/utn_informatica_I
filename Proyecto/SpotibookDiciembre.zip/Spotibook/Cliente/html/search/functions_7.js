var searchData=
[
  ['manejolibros',['ManejoLibros',['../_cliente_8h.html#a4c891a8397ada3829d6859fa937fe104',1,'ManejoLibros(int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a00db3935e02e36e2e8aa10a9843d8fb6',1,'ManejoLibros(int sockfd):&#160;FunCliente.c']]],
  ['manejousuarios',['ManejoUsuarios',['../_cliente_8h.html#a3ae608e2fed8721ceb138575c5a271ed',1,'ManejoUsuarios(int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#ab2c34a2278815bdc781640da8132dd05',1,'ManejoUsuarios(int sockfd):&#160;FunCliente.c']]],
  ['modificarnodo',['ModificarNodo',['../_cliente_8h.html#accbf0d47e3cd222be881cbf33ea8c089',1,'ModificarNodo(nodo **, int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a42556859dfd0f47e6864cb724e9f3202',1,'ModificarNodo(nodo **nodoprimero, int manejo):&#160;FunCliente.c']]],
  ['mostrarnodo',['MostrarNodo',['../_cliente_8h.html#ae5c6909a2ebebba0ffebe67594f84ef5',1,'MostrarNodo(nodo **, int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a360fd0a0892ec5397258d860a9964e06',1,'MostrarNodo(nodo **nodoprimero, int manejo):&#160;FunCliente.c']]]
];
