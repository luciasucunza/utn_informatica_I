var searchData=
[
  ['salircliente',['SalirCliente',['../_cliente_8h.html#aa5bed8e2574a7ae9699cfd5a3480dc48',1,'SalirCliente(int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#aaa194c5fce0001e51e85707cac6f1a21',1,'SalirCliente(int sockfd):&#160;FunCliente.c']]]
];
