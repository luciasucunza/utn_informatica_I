var searchData=
[
  ['funcionadmin',['FuncionAdmin',['../_cliente_8h.html#a34ea28a4c3bbff9b1d5f894d60f36457',1,'FuncionAdmin(int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a38693436dc0ca67b54538cbe3333e2c8',1,'FuncionAdmin(int sockfd):&#160;FunCliente.c']]],
  ['funcionuser',['FuncionUser',['../_cliente_8h.html#a534bf8b03922066df9083f4b523a2d8f',1,'FuncionUser(int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#ae7884d06ad58c4f0603a31e208fef4e7',1,'FuncionUser(int sockfd):&#160;FunCliente.c']]],
  ['funcliente_2ec',['FunCliente.c',['../_fun_cliente_8c.html',1,'']]]
];
