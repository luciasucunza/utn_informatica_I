var searchData=
[
  ['cargarlistarecibida',['CargarListaRecibida',['../_cliente_8h.html#ab61b1afed8d36762f299d310e357f0a2',1,'CargarListaRecibida(int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#afc284c0da910d0cd92dc6a933362c6f7',1,'CargarListaRecibida(int sockfd):&#160;FunCliente.c']]],
  ['cliente_2ec',['Cliente.c',['../_cliente_8c.html',1,'']]],
  ['cliente_2eh',['Cliente.h',['../_cliente_8h.html',1,'']]],
  ['conectaraservidor',['ConectarAServidor',['../_cliente_8h.html#ad90f023d278646eb4637333a90f60c88',1,'ConectarAServidor(char *):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a657692bcfcc62ada856185c63783a00b',1,'ConectarAServidor(char *ipservidor):&#160;FunCliente.c']]],
  ['contenido_5ft',['contenido_t',['../structcontenido__t.html',1,'']]]
];
