var searchData=
[
  ['getch',['getch',['../_cliente_8h.html#af5978fab9fa6dd4ced1c3a8ab1251f7b',1,'getch(void):&#160;FunCliente.c'],['../_fun_cliente_8c.html#af5978fab9fa6dd4ced1c3a8ab1251f7b',1,'getch(void):&#160;FunCliente.c']]]
];
