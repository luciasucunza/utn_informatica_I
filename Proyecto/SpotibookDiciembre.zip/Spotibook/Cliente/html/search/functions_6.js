var searchData=
[
  ['leerlista',['LeerLista',['../_cliente_8h.html#a9c449dfb818ef3f2ce610324d39bccc4',1,'LeerLista(nodo **, int):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a6b3b98abaa6b444e19ad5087683e857e',1,'LeerLista(nodo **nodoprimero, int manejo):&#160;FunCliente.c']]],
  ['librerarlista',['LibrerarLista',['../_cliente_8h.html#ae10fdd011456c11dec72439740ba2837',1,'LibrerarLista(nodo **):&#160;FunCliente.c'],['../_fun_cliente_8c.html#a79ed8f455d65b9d508629b629ff478d6',1,'LibrerarLista(nodo **nodoprimero):&#160;FunCliente.c']]]
];
